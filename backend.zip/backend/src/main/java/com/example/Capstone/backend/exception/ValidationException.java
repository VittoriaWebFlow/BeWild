package com.example.Capstone.backend.exception;

public class ValidationException extends RuntimeException{
    public ValidationException (String message){
        super(message);
    }
}
