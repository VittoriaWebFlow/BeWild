package com.example.Capstone.backend.model;

public enum LivelloAdrenalina {
    BASSO, MEDIO, ALTO
}
